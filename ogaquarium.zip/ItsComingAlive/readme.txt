Name: Taelor McMillan	
ID: 150140110
Email: mcmi0110@mylaurier.ca
Assignment_ID: cp411a4
Homework statement: I claim that the enclosed submission is my individual work 
Hours: 17

Check list and evaluation grid:
You need to do self evaluation for each field of the following evaluation grid. 
The field format is [self-evaluation / total marks / marker's evaluation]. 
For example, you put your self-evaluation, say 10  like [10/10/--]. 
Marker adds evaluation value, say 9, like [10/10/9].

------------------------------------------[self-evaluaiton/total/marker-evaluaiton]
Bezier curve generation and rendering
1. Create control points by clicks                                      [10/10/--]
2. Bezier curve computing (your implementation of algorithm)            [5/10/--]
3. Bezier curve rendering                                               [2/10/--]

Rotation surface generation and rendering 
4. Rotation surface generation                                          [0/10/--]
5. Rotation surface configuration                                       [0/10/--]
6. Rotation surface rendering wire and solid with OpenGL shading        [0/10/--]

GPU programming with GLSL
7. GLSL programming and phone shading                                   [0/10/--]

Texture mapping and improved solar system animation 
8. Cube texture mapping                                                 [10/10/--]
9. Solar system with texture mapping                                    [10/10/--]

Self-built library and application
10. Self-build graphics library and usage                               [5/10/--]


total:                                                                  [42/100/--]
------------------------------------------------------------------------------------

Comments: if you have any. 
