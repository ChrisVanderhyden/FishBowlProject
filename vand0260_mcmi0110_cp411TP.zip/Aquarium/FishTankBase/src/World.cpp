#include "World.hpp"
#include "Pyramid.hpp"
#include "House.hpp"
#include "table/table_leg.hpp"
#include "table/table_top.hpp"
#include "pebble.hpp"
#include "rectangle.hpp"
#include "tank.hpp"
#include "fish.hpp"
#include "Room.hpp"

fish *myfish ;
fish *fish2  ;
tank *t ;
float tmaxx, tminx, tmaxy, tminy, tmaxz, tminz ; //tank parameters
float tox, toy, toz ; //middle of the tank
int nfish = 10 ; //number of fish
float randsize() ;
int randcol() ;

World::World() {
	counter = 4;
	t = new tank() ;
	//back left leg
	list[0] = new table_leg();
	list[0]->translate(-2.5, -7, -2);

	//back right leg
	list[3] = new table_leg();
	list[3]->translate(2.5, -7, -2);

	//front left leg
	list[1] = new table_leg();
	list[1]->translate(-2.5, -7,2.5);

	//front right leg
	list[2] = new table_leg();
	list[2]->translate(2.5, -7, 2.5);


	//tank params
	tminx = -4.6 ;
	tmaxx = 0.5 ;
	tminy = -4 ;
	tmaxy = -1.45 ;
	tmaxz = 2.3 ;
	tminz = -1.7 ;
	tox = - 3 ;
	toy = - 3 ;
	toz = 1.5 ;
	for(int i = 0 ; i < nfish ; i++) {
		float si = randsize() ;
		fishes[i] = new fish(si) ;
		fishes[i]->tfish(tox + si,toy + si,toz + si) ;
		fishes[i]->minx =  tminx ;
		fishes[i]->maxx = tmaxx ;
		fishes[i]->maxy = tmaxy;
		fishes[i]->miny = tminy;
		fishes[i]->maxz = tmaxz ;
		fishes[i]->minz = tminz ;
		int col = randcol() ;
		fishes[i]->textureID2 = col ;
		fishes[i]->setcolor() ;
	}

	t->translate(0,-3.6,0) ;
	t->rotate(0,1,0,0) ;

}

World::~World(){
}


void World::drawWorld() {
		for (int i=0; i<counter; i++){
			list[i]->draw();
		}
		pebble peb ;
		peb.draw() ;


		rectangle *rec = new rectangle(); //ytop ybot zcl zfar xl xr
		rec->set(5, 0.25, -0.25, 4.25, -4.25, -6.25, 6.25); //ytop ybot zcl zfar xl xr
		rec->translate(0,-4.8,0) ;
		rec->draw() ;
		t->draw() ; //draw table

		for(int i = 0 ; i < nfish ; i++) {
			fishes[i]->draw() ;
		}


		Room *room = new Room();
		room->draw();


		glColor4f(0,0,0.78,0.2);
		glBegin(GL_QUADS);
		/* Walls */
		glVertex3f(-5.3,-4.55,3);
		glVertex3f(1.3,-4.55,3);
		glVertex3f(1.3,-.55,3);
		glVertex3f(-5.3,-.55,3);
		glEnd();

		glBegin(GL_QUADS);
		glVertex3f(-5.3,-4.55,-2);
		glVertex3f(1.3,-4.55,-2);
		glVertex3f(1.3,-.55,-2);
		glVertex3f(-5.3,-.55,-2);
		glEnd();

		glBegin(GL_QUADS);
		glVertex3f(1.3,-.55,3);
		glVertex3f(1.3,-4.55,3);
		glVertex3f(1.3,-4.55,-2);
		glVertex3f(1.3,-.55,-2);
		glEnd();

		glBegin(GL_QUADS);
		glVertex3f(-5.3,-.55,3);
		glVertex3f(-5.3,-4.55,3);
		glVertex3f(-5.3,-4.55,-2);
		glVertex3f(-5.3,-.55,-2);
		glEnd();


}
void World::fishdance() {
	for(int i = 0 ; i < nfish ; i++) {
		fishes[i]->swim(0.1) ;
	}
}

void World::resetWorld(){

}
void World::feedfish(float x, float y, float z) {
	for(int i = 0 ; i < nfish ; i++) {
		fishes[i]->food(x,y,z) ;
	}
}
float randsize() {
	int v1 = rand() % 10;
	float si = -0.7 ;
	if (v1 > 0 && v1 < 3) {
		si = -0.8 ;
		return si ;
	}
	if (v1 > 3 && v1 < 5) {
		si = -0.6 ;
		return si ;
	}
	if (v1 > 5 && v1 < 7) {
		si = -0.5 ;
		return si ;
	}
	if (v1 > 7 && v1 < 9) {
		si = -0.9 ;
		return si ;
	}
	else {return si;
	}
}
int randface() {
	int v1 = rand() % 10;
	float si = -0.7 ;
	if (v1 > 0 && v1 < 3) {
		si = -0.8 ;
		return 1 ;
	}
	if (v1 > 3 && v1 < 5) {
		si = -0.6 ;
		return 2 ;
	}
	if (v1 > 5 && v1 < 7) {
		si = -0.5 ;
		return 3 ;
	}
	if (v1 > 7 && v1 < 9) {
		si = -0.9 ;
		return 4 ;
	}
	else {return 1;
	}
}
int randcol() {
	int v1 = rand() % 3;
	if (v1 == 0) {
		return 7 ;
	}
	if (v1 == 1) {
		return 8 ;
	}
	if (v1 == 2) {
		return 9 ;
	}
	return 10 ;
}


