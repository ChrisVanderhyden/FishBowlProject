Name: Taelor Mcmillan Chris Vanderhdyen
ID: 150570260 150140110
Email: vand0260@mylaurier.ca mcmi0110@mylaurier.ca
Assignment_ID: cp411p
Homework statement: I/we claim that the enclosed submission is my individual/our team work 

Evaluation grid			
----[self-evaluaiton/total/marker-evaluaiton]
1. Proposal
- Problem description              		[5/5/]
- Creativity                       		[5/5/]
- Design consideration             		[5/5/]
- Implementation plan/schedule     		[5/5/]
- Writing of the proposal          		[5/5/]
 
2. Design & implementation
- Completeness:                    		[30/30/] 
- Algorithms:                     		[20/20/] What new algorithms are used
- New features with OpenGL:        		[20/20/] What new features are used
- Design,implementation,performance		[20/20/]

3. Project documentation
- Document, poster or video        		[10/10/]

4. Presentation
- Description                      		[5/5/]
- Demonstration                    		[5/5/]
- Team work                        		[5/5/]
- Timing                           		[5/5/]
- Overall                          		[5/5/]

Total:                             	  [150/150/]
--------------------------------------------- 